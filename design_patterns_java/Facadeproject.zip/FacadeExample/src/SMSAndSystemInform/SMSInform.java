package SMSAndSystemInform;

import Cargo.Cargo;

public class SMSInform {

	public void sendSMSStartInform(Cargo c) {
		System.out
				.println("Accepted:Informed and sms sended to the two sender and receiver Sender  about Cargo:"
						+ c.getCargoid()
						+ c.getSendercontact()
						+ "Receiver:"
						+ c.getReceivercontact());

	}
	public void sendSMSFinishInform(Cargo c) {
		System.out
				.println("Delivered:Informed and sms sended to the two sender and receiver Sender  about Cargo:"
						+ c.getCargoid()
						+ c.getSendercontact()
						+ "Receiver:"
						+ c.getReceivercontact());

	}

}
