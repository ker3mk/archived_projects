package PostOffice;

import java.util.ArrayList;

import Cargo.Cargo;

public class Postman {
	private int number;

	private ArrayList<Cargo> deliveries;

	public Postman(int number) {
		this.number = number;
		deliveries = new ArrayList<>();

	}

	public void TakeCargo(Cargo c) {
		if (!(deliveries.contains(c))) {
			deliveries.add(c);
			System.out.println("Cargo:" + c.getCargoid()
					+ " is taken by Postman whos id:" + getNumber());
		} else {
			System.out.println("!!!Cargo:" + c.getCargoid()
					+ " is FA�LED  taken by Postman whos id:" + getNumber());
		}
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public ArrayList<Cargo> getDeliveries() {
		return deliveries;
	}

	public void dropCargo(Cargo c) {
		if ((deliveries.contains(c))) {
			deliveries.remove(c);
			System.out.println("Cargo:" + c.getCargoid()
					+ " is removed from Postman whos id:" + getNumber());
		} else {
			System.out.println("!!!Cargo:" + c.getCargoid()
					+ " is FA�LED TO remove from Postman whos id:"
					+ getNumber());
		}
	}

}
