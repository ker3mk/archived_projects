package PostOffice;

import java.util.ArrayList;

import Cargo.Cargo;

public class PostOffice {

	private ArrayList<Cargo> cargos;
	private ArrayList<Postman> postmans;

	String name;

	public PostOffice(String name) {
		setName(name);
		cargos = new ArrayList<>();
		postmans = new ArrayList<>();
	}

	public void commitCargo(Cargo c) {
		if (!(cargos.contains(c))) {
			cargos.add(c);
			System.out.println("Cargo" + c.getCargoid()
					+ " is added to the Postoffice: " + getName());
		} else {
			System.out.println("Cargo" + c.getCargoid()
					+ " is FA�LED TO add Postoffice: " + getName());
		}
	}

	public void dropCargo(Cargo c) {
		if ((cargos.contains(c))) {
			cargos.remove(c);
			System.out.println("Cargo" + c.getCargoid()
					+ " is  removed from Postoffice: " + getName());
		} else {
			System.out.println("Cargo" + c.getCargoid()
					+ " is FA�LED TO removed from Postoffice: " + getName());
		}
	}

	public void addPostman(Postman e) {
		if (!(postmans.contains(e))) {
			postmans.add(e);
			System.out
					.println(getName()
							+ " Postoffice hire postman with this id: "
							+ e.getNumber());

		} else {
			System.out
					.println(getName()
							+ " Postoffice FA�LED TO hire postman it is already in postoffice with this id: "
							+ e.getNumber());
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Cargo> getCargos() {
		return cargos;
	}

	public ArrayList<Postman> getPostmans() {
		return postmans;
	}

	public void removePostman(Postman e) {
		if ((postmans.contains(e))) {
			postmans.remove(e);
			System.out.println(getName()
					+ " Postoffice fire a postman whos id is" + e.getNumber());
		} else {
			System.out.println(getName()
					+ " Postoffice FA�LED TO fire a postman whos id is"
					+ e.getNumber());
		}
	}

}
