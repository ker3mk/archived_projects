import java.util.Random;
import Cargo.Cargo;
import PostOffice.PostOffice;
import PostOffice.Postman;
import SMSAndSystemInform.SMSInform;

public class CargoSendOfficeFacade {
	PostOffice postoffice;
	Random r;

	public CargoSendOfficeFacade(String officename) {
		postoffice = new PostOffice(officename);
		System.out.println("By the Way PostOffice " + postoffice.getName()
				+ " is created.");

	}

	public void addPostman(Postman e) {
		postoffice.addPostman(e);
	}

	public void removePostman(Postman e) {
		postoffice.removePostman(e);
	}

	// COMMIT CARGO TO THE POSTOFFICE SYSTEM AND SELECT RANDOMLY A POSTMAN FOR
	// SENDING CARGO AND GIVE TASK TO HIM. AND SEND INFORM TO THE SENDER AND
	// RECEIVER
	public void SendCargo(Cargo c) {
		System.out.println("CARGO SENDING IS PROCESSING PLEASE WAIT");
		postoffice.commitCargo(c);
		r = new Random();
		int t = r.nextInt(postoffice.getPostmans().size());
		postoffice.getPostmans().get(t).TakeCargo(c);
		c.setP(postoffice.getPostmans().get(t));
		new SMSInform().sendSMSStartInform(c);
		System.out.println("------------------------------------------------");
	}
	
	public void FinishCargo(Cargo c){
		System.out.println("CARGO FINISHING IS PROCESSING PLEASE WAIT");
		postoffice.dropCargo(c);
		c.getP().dropCargo(c);
		new SMSInform().sendSMSFinishInform(c);
		System.out.println("------------------------------------------------");
		
		
	}

}
