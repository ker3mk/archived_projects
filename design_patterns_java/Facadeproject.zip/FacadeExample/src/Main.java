import Cargo.Cargo;
import Cargo.Document;
import Cargo.Packet;
import PostOffice.Postman;

public class Main {

	public static void main(String[] args) {

		Cargo c = new Document(1, "Kerem Kuzu", "Istanbul tel:020202020",
				"Ali Bahad�r", "Ankara 01111111");
		Cargo a = new Packet(100,"OSMAN","YALOVA TEL:1312412","HAL�L","D�YARBAKIR TEL:012221",44.50	);
		Postman p=new Postman(11);
		Postman p1=new Postman(12);
		CargoSendOfficeFacade csof = new CargoSendOfficeFacade("KARGO POSTA OF�S�");
		csof.addPostman(p);
		csof.addPostman(p1);
		csof.SendCargo(c);
		csof.SendCargo(a);
		csof.FinishCargo(c);

	}

}
