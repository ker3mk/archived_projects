package Cargo;

public class Document extends Cargo {

	public Document(int cargoid, String sendername, String sendercontact,
			String receivername, String receivercontact) {

		setCargoid(cargoid);
		setReceivername(receivername);
		setSendername(sendername);
		setReceivercontact(receivercontact);
		setSendercontact(sendercontact);
		System.out.println("Document created");

	}

}
