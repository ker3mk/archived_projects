package Cargo;

public class Packet extends Cargo {
	public Packet(int cargoid, String sendername, String sendercontact,
			String receivername, String receivercontact, double d) {

		setSendername(sendername);
		setCargoid(cargoid);
		setReceivername(receivername);
		setReceivercontact(receivercontact);
		setSendercontact(sendercontact);
		setKg(d);
		System.out.println("Packet created");

	}

}
