package Cargo;

import PostOffice.Postman;

public class Cargo {

	private String sendername = "";
	private String sendercontact = "";
	private String receivername = "";
	private String receivercontact = "";
	private int cargoid = 0;
	private double kg = 0;
	private Postman p=null;

	public Postman getP() {
		return p;
	}

	public void setP(Postman p) {
		this.p = p;
	}

	public String getSendername() {
		return sendername;
	}

	public void setSendername(String sendername) {
		this.sendername = sendername;
	}

	public String getSendercontact() {
		return sendercontact;
	}

	public void setSendercontact(String sendercontact) {
		this.sendercontact = sendercontact;
	}

	public String getReceivercontact() {
		return receivercontact;
	}

	public void setReceivercontact(String receivercontact) {
		this.receivercontact = receivercontact;
	}

	public String getReceivername() {
		return receivername;
	}

	public void setReceivername(String receivername) {
		this.receivername = receivername;
	}

	public int getCargoid() {
		return cargoid;
	}

	public void setCargoid(int cargoid) {
		this.cargoid = cargoid;
	}

	public Double getKg() {
		return kg;
	}

	public void setKg(double d) {
		this.kg = d;
	}

}