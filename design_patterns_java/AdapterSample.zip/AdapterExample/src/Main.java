import Adapters.GarantiBankAdapter;
import Adapters.VakifBankAdapter;
import Adapters.ICreditCard3DSecure;
import CreditCart.CreditCard;
import CreditCart.Customer;

public class Main {
	//-----------NOTES--------------------------------------------------------
	// CREDIT CARD IS USED IN BANK COMFIRMATION BUT WE NEED TO USE 3D SECURITY
	// FOR USING IT WE ADAPTEED OUR BANK MECHANISM TO DO 3DSECURE PLATFORM WITH
	// ADAPTERS OF ALL BANKS. ADAPTER ADAPTS BANKS TO WORK WITH BANK3DMANAGER.
	public static void main(String[] args) {
		Customer cus = new Customer();
		cus.setName("KEREM KUZU");
		CreditCard credit = new CreditCard(cus, "222", "111111111");
		ICreditCard3DSecure crs = new GarantiBankAdapter();
		Bank3DPaymentManager B3DPM = new Bank3DPaymentManager(crs);
		if (B3DPM.Make3DSecurePayment(credit)) {
			System.out.println("PAYMENT MADE WITH 3D SECURITY!!");
		}
		;
		System.out.println();

		ICreditCard3DSecure hb = new VakifBankAdapter();
		Bank3DPaymentManager payment = new Bank3DPaymentManager(hb);
		if (payment.Make3DSecurePayment(credit)) {
			System.out.println("PAYMENT MADE WITH 3D SECURITY!!");
		}
		;
	}

}
