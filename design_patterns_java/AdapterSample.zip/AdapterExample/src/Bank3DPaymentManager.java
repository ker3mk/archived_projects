import Adapters.ICreditCard3DSecure;
import CreditCart.CreditCard;


public class Bank3DPaymentManager {
ICreditCard3DSecure d3secure;
public Bank3DPaymentManager(ICreditCard3DSecure d3secure){
	this.d3secure=d3secure;
	
}
public boolean Make3DSecurePayment(CreditCard e){
	boolean result;
	 result=d3secure.Make3DSecurePayment(e);
	 return result;
	 
}
}
