package Banks;
import CreditCart.CreditCard;


public class VakifBank {
	
	
	public boolean CreditCardConfirm(CreditCard a){
		// CODES HERE
		return true;
	}
	
	
	public boolean SMSMessageConfirm(){
		// CODES HERE
		return true;
	}
}
