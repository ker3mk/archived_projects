package Banks;

public class ExtraSecurityForGarantiBank {

	
	public boolean ExtrasecurityStep(){
		System.out.println("Extra Security used for Garanti bankasi");
	// CODES HERE
		return true;
	}
}
