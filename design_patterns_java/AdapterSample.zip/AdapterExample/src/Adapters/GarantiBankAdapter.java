package Adapters;

import Banks.ExtraSecurityForGarantiBank;
import Banks.GarantiBank;
import CreditCart.CreditCard;

public class GarantiBankAdapter implements ICreditCard3DSecure {
	// IT ADAPTEES THE GARANTI BANK FOR USING IN 3D SECURE PAYMENT METHOD
	GarantiBank gb;
	ExtraSecurityForGarantiBank esfgb;

	public GarantiBankAdapter() {
		gb = new GarantiBank();
		esfgb = new ExtraSecurityForGarantiBank();

	}

	public boolean Make3DSecurePayment(CreditCard e) {
		// CODES HERE
		boolean result = gb.CreditCardConfirm(e) & gb.SMSMessageConfirm()
				& esfgb.ExtrasecurityStep();
		System.out.println("Process 3d secure GARANTI BANKASI adapter");
		return result;
	}

}
