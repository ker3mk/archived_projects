package Adapters;

import CreditCart.CreditCard;


public interface ICreditCard3DSecure {

	
	
public boolean Make3DSecurePayment(CreditCard e);
}
