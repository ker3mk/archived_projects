package Adapters;
import Banks.IsBank;
import CreditCart.CreditCard;

public class IsBankAdapter implements ICreditCard3DSecure {
	// IT ADAPTEES THE ISBANK FOR USING IN 3D SECURE PAYMENT METHOD
	IsBank ib;
	public IsBankAdapter(){
	ib=new IsBank();
	
	}
	public boolean Make3DSecurePayment(CreditCard e) {
		// CODES HERE
			 boolean result=ib.CreditCardConfirm(e)&ib.SMSMessageConfirm();
			 System.out.println("Process 3d secure IS BANKASI adapter");
	return result;
	}

}