package Adapters;
import Banks.VakifBank;

import CreditCart.CreditCard;

public class VakifBankAdapter implements ICreditCard3DSecure {
	// IT ADAPTEES THE VAKIFBANK FOR USING IN 3D SECURE PAYMENT METHOD
	VakifBank vb;
	public VakifBankAdapter() {
		vb=new VakifBank();
	}
	
	public boolean Make3DSecurePayment(CreditCard e) {
		// CODES HERE
			 boolean result=vb.CreditCardConfirm(e)&vb.SMSMessageConfirm();
			 System.out.println("Process 3d secure VAKIF BANK adapter");
	return result;
	}

}