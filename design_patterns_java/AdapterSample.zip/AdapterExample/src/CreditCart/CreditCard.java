package CreditCart;

public class CreditCard {
Customer c;
String cvc2;
String cardnumber;


public CreditCard(Customer c,String cvc2,String cardnumber){
	setC(c);
	setCvc2(cvc2);
	setCardnumber(cardnumber);
}
public String getCvc2() {
	return cvc2;
}

public void setCvc2(String cvc2) {
	this.cvc2 = cvc2;
}

public String getCardnumber() {
	return cardnumber;
}

public void setCardnumber(String cardnumber) {
	this.cardnumber = cardnumber;
}

public Customer getC() {
	return c;
}

public void setC(Customer c) {
	this.c = c;
}


}
