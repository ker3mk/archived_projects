import Strategies.IDbConnectionStrategy;
import Strategies.MSSQLConnection;
import Strategies.MongoDBConnection;
import Strategies.ODBCConnection;


public class Main {
	
	public static void main(String[] args) {
		IDbConnectionStrategy idb=new ODBCConnection();
		DBStrategyContext dbs=new DBStrategyContext(idb);
		dbs.ConnectDB("localhost", "kerem", "123", "java");
		dbs.CommitQuery("query");
		
		System.out.println("---------------------------------");
		IDbConnectionStrategy idb2=new MSSQLConnection();
		DBStrategyContext dbs2=new DBStrategyContext(idb2);
		dbs2.ConnectDB("localhost", "Kuzu", "888", "javakk");
		dbs2.CommitQuery("query");
		
		System.out.println("---------------------------------");
		IDbConnectionStrategy idb3=new MongoDBConnection();
		DBStrategyContext dbs3=new DBStrategyContext(idb3);
		dbs3.ConnectDB("localhost", "AL�", "888", "MONGO");
		dbs3.CommitQuery("query");
		dbs3.CloseConnection();
		
		
		
		
		
		
	}


}
