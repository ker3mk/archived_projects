package Strategies;
import java.sql.ResultSet;


public interface IDbConnectionStrategy {

public void ConnectDB(String host,String user,String pass,String dbname);

public void CommitQuery(String q);

public void CloseConnection();

}
