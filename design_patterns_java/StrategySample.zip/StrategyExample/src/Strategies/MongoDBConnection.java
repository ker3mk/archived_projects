package Strategies;
import java.sql.ResultSet;


public class MongoDBConnection implements IDbConnectionStrategy {

	@Override
	public void ConnectDB(String host, String user, String pass, String dbname) {
		System.out.println(" MongoDBConnectionmade: "+host+" "+ user+" "+pass+" "+dbname);
		
	}

	@Override
	public void CommitQuery(String q) {
		// TODO Auto-generated method stub
		System.out.println("Commit Query MongoDBConnection");
	}

	@Override
	public void CloseConnection() {
		// TODO Auto-generated method stub
		System.out.println("Close Connection  MongoDBConnection");
	}

	}


