package Strategies;
import java.sql.ResultSet;


public class ODBCConnection implements IDbConnectionStrategy {

	@Override
	public void ConnectDB(String host, String user, String pass, String dbname) {
		System.out.println("ODBCConnection made: "+host+" "+ user+" "+pass+" "+dbname);
		
	}

	@Override
	public void CommitQuery(String q) {
		// TODO Auto-generated method stub
		System.out.println("Commit Query ODBC");
	}

	@Override
	public void CloseConnection() {
		// TODO Auto-generated method stub
		System.out.println("Close Connection ODBC");
	}

}
