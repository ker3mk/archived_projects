package Strategies;
import java.sql.ResultSet;


public class MySQLConnection implements IDbConnectionStrategy {

	@Override
	public void ConnectDB(String host, String user, String pass, String dbname) {
		System.out.println("MySQLConnection made: "+host+" "+ user+" "+pass+" "+dbname);
		
	}

	@Override
	public void CommitQuery(String q) {
		// TODO Auto-generated method stub
		System.out.println("Commit Query MySQLConnection");
	}

	@Override
	public void CloseConnection() {
		// TODO Auto-generated method stub
		System.out.println("Close Connection MySQLConnection");
	}


}
