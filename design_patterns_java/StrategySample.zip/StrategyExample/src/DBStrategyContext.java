import Strategies.IDbConnectionStrategy;


public class DBStrategyContext {

	
	IDbConnectionStrategy idb;
	
	public DBStrategyContext(IDbConnectionStrategy idb){
		this.idb=idb;
	}
	
	public void ConnectDB(String host, String user, String pass, String dbname) {
		idb.ConnectDB(host, user, pass, dbname);
	}

	public void CommitQuery(String q) {
		idb.CommitQuery(q);
	}

	public void CloseConnection() {
		idb.CloseConnection();
	}

}
